package com.briontacticalsystems.tsubuild152;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

public class MainActivity<pubic> extends AppCompatActivity {

    private ProgressBar progressBar;
    private WebView mywebView;
    String webUrl = "https://student.tsu.edu.ph";

    private SwipeRefreshLayout swipeRefreshLayout;

    RelativeLayout relativeLayout;
    Button NointernetBtn;

    @RequiresApi(api = Build.VERSION_CODES.M)
    @SuppressLint("SetJavaScriptEnabled")

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // WebView Tweaks

        mywebView = (WebView) findViewById(R.id.webview);
        mywebView.setWebViewClient(new WebViewClient(){
            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                internetCheck();
                super.onReceivedError(view, request, error);
            }
        });

        mywebView.getSettings().setAllowFileAccessFromFileURLs(true);
        mywebView.getSettings().setAllowUniversalAccessFromFileURLs(true);
        mywebView.getSettings().setAllowFileAccess(true);
        mywebView.getSettings().setAllowContentAccess(true);
        mywebView.setInitialScale(1);
        mywebView.getSettings().setLoadWithOverviewMode(true);
        mywebView.getSettings().setUseWideViewPort(true);
        mywebView.getSettings().setOffscreenPreRaster(true);
        mywebView.getSettings().setNeedInitialFocus(true);
        mywebView.getSettings().setDatabaseEnabled(true);
        mywebView.getSettings().setDomStorageEnabled(true);
        mywebView.getSettings().setRenderPriority(WebSettings.RenderPriority.HIGH);
        mywebView.loadUrl(webUrl);

        WebSettings mywebSettings = mywebView.getSettings();
        mywebSettings.setJavaScriptEnabled(true);
        mywebSettings.setEnableSmoothTransition(true);
        mywebSettings.setLayoutAlgorithm(WebSettings.LayoutAlgorithm.NORMAL);

        // Progress Bar

        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        mywebView.setWebChromeClient(new WebChromeClient(){

            @Override
            public void onProgressChanged(WebView view, int progress) {

                progressBar.setProgress(progress);

                if(progress < 100 && progressBar.getVisibility() == ProgressBar.GONE){

                    progressBar.setVisibility(ProgressBar.VISIBLE);


                }

                if (progress == 100){

                    progressBar.setVisibility(ProgressBar.GONE);

                }

            }



        });

        // Pull Down Refresh WebView Page

        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                swipeRefreshLayout.setRefreshing(true);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        swipeRefreshLayout.setRefreshing(false);
                        mywebView.reload();
                    }
                },1500);
            }
        });
        swipeRefreshLayout.setColorSchemeColors(
                getResources().getColor(android.R.color.holo_orange_light),
                getResources().getColor(android.R.color.holo_red_light),
                getResources().getColor(android.R.color.holo_orange_dark),
                getResources().getColor(android.R.color.holo_red_dark)
        );

        // No internet Warning Message and Refresh

        NointernetBtn = (Button) findViewById(R.id.Refresh);
        relativeLayout = (RelativeLayout) findViewById(R.id.noCon);

        internetCheck();

        NointernetBtn.setOnClickListener(new View.OnClickListener(){
           @Override
           public void onClick(View view){
               internetCheck();
           }
        });

    }

    @Override
    public void onBackPressed() {
        if(mywebView.canGoBack()){

            mywebView.goBack();

        }else{

            super.onBackPressed();

        }
    }

    public void internetCheck(){

        ConnectivityManager connectivityManager = (ConnectivityManager) this.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo mobiledata = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        NetworkInfo wifi = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);

        if(mobiledata.isConnected()){
            mywebView.setVisibility(View.VISIBLE);
            swipeRefreshLayout.setVisibility(View.VISIBLE);
            relativeLayout.setVisibility(View.GONE);
            mywebView.reload();

        } else if(wifi.isConnected()){
            mywebView.setVisibility(View.VISIBLE);
            swipeRefreshLayout.setVisibility(View.VISIBLE);
            relativeLayout.setVisibility(View.GONE);
            mywebView.reload();
        } else {
            mywebView.setVisibility(View.GONE);
            swipeRefreshLayout.setVisibility(View.GONE);
            relativeLayout.setVisibility(View.VISIBLE);
        }

    }
}